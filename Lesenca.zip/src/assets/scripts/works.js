import jquery from "jquery/dist/jquery.min.js"
import slick from "slick-carousel/slick/slick"
import jqueryScript from "./modules/jqueryScript"
import masonry from "./modules/masonry"
import FontAwesomeFree from "@fortawesome/fontawesome-free/js/all"


slick();
jquery();
jqueryScript();
masonry();
FontAwesomeFree();